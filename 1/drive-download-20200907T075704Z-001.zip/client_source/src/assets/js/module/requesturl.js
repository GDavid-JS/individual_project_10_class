const urls = {
  laptops: `http://localhost:5000/laptors`,
  smartphones: `http://localhost:5000/smartphones`,
  processors: `http://localhost:5000/processors`,
  ram: `http://localhost:5000/ram`,
  videoCards: `http://localhost:5000/video_cards`,
  ssd: `http://localhost:5000/ssd`,
  hdd: `http://localhost:5000/hdd`,
  monitors: `http://localhost:5000/monitors`,
  main: `http://localhost:5000/database`
}

export { urls };